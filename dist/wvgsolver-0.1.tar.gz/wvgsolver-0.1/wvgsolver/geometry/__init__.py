from .materials import DielectricMaterial
from .structures import PolygonStructure, BoxStructure, CylinderStructure